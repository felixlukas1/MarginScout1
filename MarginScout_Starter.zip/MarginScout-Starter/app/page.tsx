export default function Home(){
return <main style={{fontFamily:"Arial",padding:40}}>
<h1>MarginScout</h1>
<p>Erste Version der App.</p>
<input placeholder="Kategorie"/>
<button>Analysieren</button>
</main>
}